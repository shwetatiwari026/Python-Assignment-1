# Assignment 1 – Python Solutions

This folder contains beginner-friendly Python solutions based on the three assignment screenshots.
Each exercise is saved in a separate `.py` file and includes simple comments where they help explain the logic.

## How to run
1. Extract the ZIP file.
2. Open the extracted folder in VS Code.
3. Open the required `.py` file.
4. Run it using the Run button, or in the terminal:
   `python filename.py`
5. Enter the values when the program asks for them.

Use Python 3. Most programs use only built-in Python features. The geometry package example uses files inside its own folder.

## Folder guide
- `01_Conditional` – Electricity bill, loan approval, number classification, exam result
- `02_Loops` – Automorphic number, palindrome number series, LCM/HCF, password retry, star patterns
- `03_Strings` – Palindrome, longest word, anagram, duplicate removal, compression
- `04_Data_Structures` – Lists, tuples, sets, dictionaries
- `05_Functions_Recursion` – Factorial, sum, reverse string, power
- `06_Errors_Exceptions` – Age, bank withdrawal, password validation
- `07_Modules_Packages` – math, random, datetime, geometry package
- `08_OOP` – Inheritance, overriding, operator overloading, encapsulation, game characters

## Small assumptions / notes
1. **Loan approval:** The sheet lists three conditions and three possible outcomes, but does not explain when to use “Conditionally Approved”. This solution uses all 3 conditions = Approved, exactly 2 = Conditionally Approved, and fewer than 2 = Rejected.
2. **Exam division:** The solution assumes each subject is out of 100. It checks for a fail first (any subject below 33), then uses the average for division. The sheet does not specify a division for a passing average below 40%, so the program reports that no division is specified.
3. **String compression example:** The sheet shows `aaaabbc -> a3b2c1`, but `aaaabbc` contains four `a` characters. The program counts the input accurately and returns `a4b2c1`. If the intended input was `aaabbc`, the result is `a3b2c1`.
4. **Library management:** The sheet only says to use a dictionary mapping book names to quantities. This example supports showing, adding, issuing, and returning books.
5. **Student marks:** Each student is stored with a list of subject marks. A student is counted as a failure if any subject mark is below 33.
6. **Demo credentials:** The password retry and ATM programs use sample credentials only. Change them for practice; do not use these as real account credentials.
7. **Geometry package:** Run `main.py` from inside `07_Modules_Packages/geometry` so the local imports work.

These are learning examples. Read each program and change the inputs to see how the conditions and loops behave.
