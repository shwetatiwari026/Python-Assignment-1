units = int(input("Enter units consumed: "))

if units < 0:
    print("Units cannot be negative.")
else:
    if units <= 100:
        bill = units * 5
    elif units <= 300:
        bill = (100 * 5) + (units - 100) * 7
    else:
        bill = (100 * 5) + (200 * 7) + (units - 300) * 10

    print(f"Bill before surcharge: Rs. {bill:.2f}")

    if bill > 2000:
        bill = bill + (bill * 0.05)
        print("A 5% surcharge has been added.")

    print(f"Total electricity bill: Rs. {bill:.2f}")
